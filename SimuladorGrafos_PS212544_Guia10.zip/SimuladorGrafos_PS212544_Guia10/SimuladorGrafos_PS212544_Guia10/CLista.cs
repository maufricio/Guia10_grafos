﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorGrafos_PS212544_Guia10
{
    public class CLista
    {
        //Atributos
        private CVertice aElemento; //vertice o nodo -> 3
        private CLista aSubLista; //Lista dentro de esta lista
        private int aPeso;

        //Constructores
        public CLista()
        {
            aElemento = null;
            aSubLista = null;
            aPeso = 0;
        }

        //Es como que hace una copia del objeto del parametro
        public CLista(CLista pLista)
        {
            if(pLista != null)
            {
                aElemento = pLista.aElemento;
                aSubLista = pLista.aSubLista;
                aPeso = pLista.aPeso;
            }
        }

        public CLista(CVertice pElemento, CLista pSubLista, int pPeso)
        {
            aElemento = pElemento;
            aSubLista = pSubLista;
            aPeso = pPeso;
        }

        //Propiedades
        public CVertice Elemento
        {
            get => this.aElemento;
            set => this.aElemento = value;
        }

        public CLista SubLista
        {
            get => aSubLista;
            set => aSubLista = value;
        }

        public int Peso
        {
            get => aPeso;
            set => aPeso = value;
        }


        //Métodos
        public bool EsVacia()
        {
            //Retornar el aELemento si es nulo
            return aElemento == null;
        }

        public bool ExisteElemento(CVertice pElemento)
        {
            if ((aElemento != null) && (pElemento != null))
                return (aElemento.Equals(pElemento) || (aSubLista.ExisteElemento(pElemento)));
            else
                return false;
        }


        public void Agregar(CVertice pElemento, int pPeso)
        {
            if(pElemento != null)
            {
                if(aElemento == null)
                {
                    aElemento = new CVertice(pElemento.Valor);
                    aPeso = pPeso;
                    aSubLista = new CLista();
                } else
                {
                    if (!ExisteElemento(pElemento))
                        aSubLista.Agregar(pElemento, pPeso);

                }
            }
        }

        public void Eliminar(CVertice pElemento)
        {
            if(aElemento != null)
            {
                if (aElemento.Equals(pElemento))
                {
                    aElemento = aSubLista.aElemento; //null
                    aSubLista = aSubLista.aSubLista;
                }
                else
                    aSubLista.Eliminar(pElemento);
            }
        }

        public int NroElementos()
        {
            if (aElemento != null)
                return 1 + aSubLista.NroElementos(); //retorna un incremento de lo que NroELementos tiene devuelto por el momento
            else
                return 0;
        }

        public object IesimoElemento(int posicion)
        {
            if ((posicion > 0) && (posicion <= NroElementos()))
            {
                if (posicion == 1)
                    return aElemento;
                else
                    return aSubLista.IesimoElemento(posicion - 1);
            }
            else
                return null;
        }

        public object IesimoElementoPeso(int posicion)
        {
            if ((posicion > 0) && (posicion <= NroElementos()))
            {
                if (posicion == 1)
                    return aPeso;
                else
                    return aSubLista.IesimoElementoPeso(posicion - 1);
            }
            else
                return 0;
        }

        public int PosicionElemento(CVertice pElemento)
        {
            if((aElemento != null) || (ExisteElemento(pElemento)))
            {
                if (aElemento.Equals(pElemento))
                    return 1;
                else
                    return 1 + aSubLista.PosicionElemento(pElemento);
            }else
                return 0;
        }
    }
}
